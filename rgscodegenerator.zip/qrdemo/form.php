<?php
require 'config.php';

?>
<!DOCTYPE html>
<html>
<head>
    <title>RGS Voucher Code Generator</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="style.css">
    <img src="RGS INTERCONNECT.png" alt="RGS" width="400" height="222" class="left"> 
    
</head>
<body>
    <h1>Code Generator</h1>

    <form method="post" action="generate.php">

    
        <label for="text">name</label>
        <textarea id="text" name="text"></textarea>
        <br>
        <button>Generate</button>

    </form>
</body>
</html>